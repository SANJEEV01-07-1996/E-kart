<?php
header("Content-Type: application/json");
header("Expires: 0");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


include_once('../../includes/crud.php');
$db=new Database();
$db->connect(); 
include_once('../../includes/variables.php');

/* 
-------------------------------------------
APIs for Delivery Boys
-------------------------------------------
1. login
2. get_delivery_boy_by_id  
3. update_delivery_boy_profile 
4. get_orders_by_delivery_boy_id 
5. get_order_by_id
6. update_order_status
7. get_fund_transfers
-------------------------------------------

-------------------------------------------

*/
if(!$_POST['accesskey'] AND $_POST['accesskey'] == $access_key){
    $response['error'] = true;
	$response['message'] = "No Accsess key found!";
	print_r(json_encode($response));
	return false;
	exit();
}



	
if(isset($_POST['login'])){
     /* 
    1.Login
        accesskey:90336
        mobile:9876543210
        password:12345678
    */
    
    if(empty(trim($_POST['mobile']))){
        $response['error'] = true;
    	$response['message'] = "Mobile should be filled!";
    	print_r(json_encode($response));
    	return false;
    	exit();
    }

    if(empty($_POST['password'])){
        $response['error'] = true;
    	$response['message'] = "Password should be filled!";
    	print_r(json_encode($response));
    	return false;
    	exit();
    }
    
    $mobile = $db->escapeString(trim($_POST['mobile']));
    $password = md5($_POST['password']);
    $sql = "SELECT * FROM delivery_boys	WHERE mobile = '".$mobile."' AND password = '".$password."'";
	$db->sql($sql);
	$res=$db->getResult();
	$num = $db->numRows($res);
	$db->disconnect(); 
	if($num == 1){
	    if($res[0]['status'] == 0){
	        $response['error'] = true;
	        $response['message'] = "It seems your acount is not active please contact admin for more info!"; 
	        $response['data'] = array();
		}else{
			$response['error'] = false;
            $response['message'] = "Delivery Boy Login Susseccfully";
            $response['data'] = $res[0];
		}
	}else{
		$response['error'] = true;
		$response['message'] = "No data found!";
	}
	print_r(json_encode($response));
}else {
	$response['error'] = true;
	$response['message'] = "Invalid Call of API!";
}
//


/* 
---------------------------------------------------------------------------------------------------------
*/
	
if(isset($_POST['get_delivery_boy_by_id'])){
    
    /* 
    2.get_delivery_boy_by_id
        accesskey:90336
        id:78
    */
    $id = $db->escapeString(trim($_POST['id']));
    $sql = "SELECT * FROM delivery_boys	WHERE id = '".$id."'";
	$db->sql($sql);
	$res=$db->getResult();
	$num = $db->numRows($res);
	$db->disconnect(); 
	if($num == 1){
    	$response['error'] = false;
        $response['message'] = "Delivery Boy Data Fetched Susseccfully";
        /*foreach($res as $row){
            $data = array(
				'id'=>$row['id'], 
				'name'=>$row['name'], 
				'mobile'=>$row['mobile'], 
				'password'=>$row['password'], 
				'address'=>$row['address'], 
				'bonus'=>$row['bonus'], 
				'balance'=>$row['balance'], 
				'status'=>$row['status']
			); 
        }*/
        $response['data'] = $res;
	}else{
		$response['error'] = true;
		$response['message'] = "No data found!";
	}
	print_r(json_encode($response));
}else {
	$response['error'] = true;
	$response['message'] = "Invalid Call of API!";
}
/* 
---------------------------------------------------------------------------------------------------------
*/
	
if(isset($_POST['get_orders_by_delivery_boy_id'])){
    
    /* 
    4.get_orders_by_delivery_boy_id
        accesskey:90336
        id:40
        offset:0        // {optional}
        limit:10        // {optional}
        
        sort:id / user_id           // {optional}
        order:DESC / ASC            // {optional}
        search:search_value         // {optional}
    */
    $id =  $db->escapeString(trim($_POST['id']));
  
    
    $offset = ( isset($_POST['offset']) && !empty(trim($_POST['offset'])) && is_numeric($_POST['offset']) ) ? $db->escapeString(trim($_POST['offset'])) : 0;
    $limit = ( isset($_POST['limit']) && !empty(trim($_POST['limit'])) && is_numeric($_POST['limit']) ) ? $db->escapeString(trim($_POST['limit'])) : 10;
    
    $sort = ( isset($_POST['sort']) && !empty(trim($_POST['sort'])) ) ? $db->escapeString(trim($_POST['sort'])) : 'id';
    $order = ( isset($_POST['order']) && !empty(trim($_POST['order'])) ) ? $db->escapeString(trim($_POST['order'])) : 'DESC';
    
    $sql = "SELECT * FROM orders WHERE delivery_boy_id = '".$id."' ORDER BY '".$sort."' $order LIMIT $offset,$limit";
    $db->sql($sql);
	$res=$db->getResult();
	$num = $db->numRows($res);
	$db->disconnect(); 
	if($num >0){
    	$response['error'] = false;
        $response['message'] = "Ordered Data by Delivery boy id Fetched Susseccfully";
        foreach($res as $row){
            $data[] = array(
				'id'=>$row['id'], 
				'user_id'=>$row['user_id'], 
				'delivery_boy_id'=>$row['delivery_boy_id'], 
				'mobile'=>$row['mobile'], 
				'total'=>$row['total'], 
				'delivery_charge'=>$row['delivery_charge'], 
				'tax_amount'=>$row['tax_amount'], 
				'tax_percentage'=>$row['tax_percentage'], 
				'wallet_balance'=>$row['wallet_balance'], 
				'discount'=>$row['discount'], 
				'promo_code'=>$row['promo_code'], 
				'promo_discount'=>$row['promo_discount'], 
				'final_total'=>$row['final_total'],
				'payment_method'=>$row['payment_method'],
				'address'=>$row['address'],
				'latitude'=>$row['latitude'],
				'longitude'=>$row['longitude'],
				'delivery_time'=>$row['delivery_time'],
				'status'=>$row['status'],
				'active_status'=>$row['active_status'],
				'date_added'=>$row['date_added']
			); 
        }
        $response['data'] = $data;
	}else{
		$response['error'] = true;
		$response['message'] = "No data found!";
	}
	print_r(json_encode($response));
}else {
	$response['error'] = true;
	$response['message'] = "Invalid Call of API!";
}


?>